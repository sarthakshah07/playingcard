import React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
// import LoginRoundedIcon from "@mui/icons-material/LoginRounded";
import MyButton from "../MyButton";
import "./_logincard.css";
import { Grid } from "@mui/material";
import Textfield from "./Textfield";
import CardHeader from "@mui/material/CardHeader";

const card = (
  <React.Fragment>
    <Card className="loginbox">
      <CardContent>
        <CardHeader title="Sign in" variant="h5" className="Cardheader" />
        <Typography sx={{ mt: 1.5, mb: 1.5 }} color="text.secondary">
          <Textfield />
        </Typography>
        <Typography variant="body2" className="boxfooter">
          <MyButton
            className="signin"
            fullWidth={false}
            title="sign in"
            variant="contained"
          />
          <MyButton
            className="forgotpassword"
            fullWidth={false}
            size="small"
            title= "Forgot password ?"
            variant="text"
          />
          <br />
        </Typography>
      </CardContent>
    </Card>
  </React.Fragment>
);

export default function Maincard() {
  return (
    <Grid
      className="container"
    >
      <Grid>
        <Box>
          {card}
        </Box>
      </Grid>
    </Grid>
  );
}
